__title__ = "attrs"
__description__ = "Attributes without boilerplate."
__uri__ = "https://attrs.readthedocs.org/"

__author__ = "Erik Nilsen"
__email__ = ""

__license__ = "MIT"
__copyright__ = "Copyright (c) 2015 Erik"
__version__ = "0.0.1"
